Miz: 
1. Naive Bayes
2. Bayesian Belief Networks
(this was the cause of delay and why our assignment has been submitted so late, I apologize for the group and request that their marks not be deducted for my mistake)

Parth:
3. Bayesian Linear Regression

Kanthi:
4> EM maximization 